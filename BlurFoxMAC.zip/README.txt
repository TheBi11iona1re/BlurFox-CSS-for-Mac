## blurredfox

### A Blurered MacOS CSS theme
Credit to manilarome for the orginal theme

## Requirements

+ The latest Firefox
+ the css blurfox settings for linux work

## Notes

+ Works on macOS.
+ Transparency is broken on Windows 10 (has graphical glitches like flickering). The [solid color scheme](https://github.com/manilarome/blurredfox/blob/master/colors/solid.css) *may* work.
+ No, the vertical titlebar is not included. Switch to Linux, then use AwesomeWM to achieve this gloriousness.

